// 生成扩展图标（16/32/48/128 PNG），不依赖任何绘图库。
// 图案：蓝色圆角方块 ＋ 白色对话气泡 ＋ 三条深色横线（「解释一段文字」的意象）。
// 手法：4 倍超采样后取平均，等于手工做了抗锯齿。
const fs = require('node:fs')
const path = require('node:path')
const zlib = require('node:zlib')

// ---- 最小 PNG 编码器 ----
const CRC_TABLE = (() => {
  const table = new Int32Array(256)
  for (let n = 0; n < 256; n += 1) {
    let c = n
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    table[n] = c
  }
  return table
})()

function crc32(buffer) {
  let c = 0xffffffff
  for (let i = 0; i < buffer.length; i += 1) c = CRC_TABLE[(c ^ buffer[i]) & 0xff] ^ (c >>> 8)
  return (c ^ 0xffffffff) >>> 0
}

function chunk(type, data) {
  const length = Buffer.alloc(4)
  length.writeUInt32BE(data.length, 0)
  const typeBuffer = Buffer.from(type, 'ascii')
  const crc = Buffer.alloc(4)
  crc.writeUInt32BE(crc32(Buffer.concat([typeBuffer, data])), 0)
  return Buffer.concat([length, typeBuffer, data, crc])
}

function encodePng(width, height, rgba) {
  const ihdr = Buffer.alloc(13)
  ihdr.writeUInt32BE(width, 0)
  ihdr.writeUInt32BE(height, 4)
  ihdr[8] = 8 // 位深
  ihdr[9] = 6 // 颜色类型：RGBA
  const raw = Buffer.alloc((width * 4 + 1) * height)
  for (let y = 0; y < height; y += 1) {
    raw[y * (width * 4 + 1)] = 0 // 每行前缀：filter = none
    rgba.copy(raw, y * (width * 4 + 1) + 1, y * width * 4, (y + 1) * width * 4)
  }
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0))
  ])
}

// ---- 画图 ----
const BG = [37, 99, 235] // 蓝
const FG = [255, 255, 255] // 白

function inRoundedRect(px, py, x, y, w, h, r) {
  if (px < x || py < y || px >= x + w || py >= y + h) return false
  const cx = Math.min(Math.max(px, x + r), x + w - r)
  const cy = Math.min(Math.max(py, y + r), y + h - r)
  const dx = px - cx
  const dy = py - cy
  return dx * dx + dy * dy <= r * r
}

function render(size, scale) {
  const W = size * scale
  const H = size * scale
  const out = Buffer.alloc(W * H * 4)
  const radius = W * 0.22
  // 气泡：居中偏上的圆角矩形
  const bx = W * 0.2
  const by = H * 0.2
  const bw = W * 0.6
  const bh = H * 0.46
  const br = W * 0.12
  // 气泡下的小尾巴
  const tx = W * 0.32
  const ty = by + bh
  const tw = W * 0.16
  const th = H * 0.14
  // 三条横线
  const lines = [0.33, 0.43, 0.53].map((ratio) => ({
    x: bx + bw * 0.14,
    y: H * ratio,
    w: bw * (ratio === 0.53 ? 0.42 : 0.72),
    h: H * 0.055
  }))

  for (let y = 0; y < H; y += 1) {
    for (let x = 0; x < W; x += 1) {
      let color = null
      if (inRoundedRect(x, y, 0, 0, W, H, radius)) color = BG
      if (
        inRoundedRect(x, y, bx, by, bw, bh, br) ||
        inRoundedRect(x, y, tx, ty, tw, th, th * 0.25)
      ) {
        color = FG
      }
      if (color === FG) {
        for (const line of lines) {
          if (x >= line.x && x < line.x + line.w && y >= line.y && y < line.y + line.h) {
            color = BG
          }
        }
      }
      if (color !== null) {
        const i = (y * W + x) * 4
        out[i] = color[0]
        out[i + 1] = color[1]
        out[i + 2] = color[2]
        out[i + 3] = 255
      }
    }
  }
  return { W, H, out }
}

function downsample(size, scale) {
  const { W, H, out } = render(size, scale)
  const result = Buffer.alloc(size * size * 4)
  const area = scale * scale
  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      let r = 0
      let g = 0
      let b = 0
      let a = 0
      for (let sy = 0; sy < scale; sy += 1) {
        for (let sx = 0; sx < scale; sx += 1) {
          const i = ((y * scale + sy) * W + (x * scale + sx)) * 4
          const alpha = out[i + 3] / 255
          r += out[i] * alpha
          g += out[i + 1] * alpha
          b += out[i + 2] * alpha
          a += alpha
        }
      }
      const o = (y * size + x) * 4
      if (a > 0) {
        result[o] = Math.round(r / a)
        result[o + 1] = Math.round(g / a)
        result[o + 2] = Math.round(b / a)
      }
      result[o + 3] = Math.round((a / area) * 255)
    }
  }
  return encodePng(size, size, result)
}

const dir = process.argv[2]
if (!dir) {
  console.error('用法：node make-icons.cjs <输出目录>')
  process.exit(1)
}
fs.mkdirSync(dir, { recursive: true })
for (const size of [16, 32, 48, 128]) {
  const buffer = downsample(size, 4)
  fs.writeFileSync(path.join(dir, `icon${size}.png`), buffer)
  console.log(`icon${size}.png  ${buffer.length} 字节`)
}
